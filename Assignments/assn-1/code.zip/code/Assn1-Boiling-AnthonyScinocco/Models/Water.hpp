class Water :public Substance
{
    public:
        Water()
        {
            setCelcius(100);
            setFahrenheit(212);
            setkelvin(373.15);
        }
};