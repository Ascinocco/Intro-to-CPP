#!/usr/bin/env bash
rm -f main
make main