class Silver :public Substance
{
    public:
        Silver()
        {
            setCelcius(2193);
            setFahrenheit(3979.4);
            setkelvin(2466.15);
        }
};