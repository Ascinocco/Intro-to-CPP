class Gold :public Substance
{
    public:
        Gold()
        {
            setCelcius(2660);
            setFahrenheit(4820);
            setkelvin(2933.15);
        }
};