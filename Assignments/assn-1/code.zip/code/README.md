# Author
- Anthony Scinocco 200271982

# Thoughts for next time

- Standardize exits
    - stop using random input for exiting the app

- Learn more about constructors in c++
