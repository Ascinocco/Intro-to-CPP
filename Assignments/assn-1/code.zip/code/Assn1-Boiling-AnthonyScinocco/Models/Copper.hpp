class Copper :public Substance
{
    public:
        Copper()
        {
            setCelcius(1187);
            setFahrenheit(2168.6);
            setkelvin(1460.15);
        }
};