class Mercury :public Substance
{
    public:
        Mercury()
        {
            setCelcius(357);
            setFahrenheit(674.6);
            setkelvin(630.15);
        }
};